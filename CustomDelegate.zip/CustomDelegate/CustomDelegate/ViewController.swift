//
//  ViewController.swift
//  CustomDelegate
//
//  Copyright © 2017 Sid14291. All rights reserved.
//

import UIKit
import Foundation

class ViewController: UIViewController,OtherViewDelegate
{
    static var launchModel: ViewController? = nil
    var user : String = ""
    var responseData : String = ""
    @IBOutlet weak var textValue: UITextField!
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool)
    {
        responseData = user
        debugPrint(responseData)
    }

    @IBAction func btn(_ sender: Any)
    {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "OtherViewController") as! OtherViewController
        nextViewController.username1 = textValue.text!
        nextViewController.delegateModel = self
        self.navigationController?.pushViewController(nextViewController, animated: true)

    }
    func Username(Username : String)-> Void
    {
        user = Username
    }
}

