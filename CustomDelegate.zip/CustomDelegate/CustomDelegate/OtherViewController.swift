//
//  OtherViewController.swift
//  CustomDelegate
//
//  Copyright © 2017 Sid14291 All rights reserved.
//

import Foundation
import UIKit

protocol OtherViewDelegate : class
{
    func Username(Username : String)-> Void
}


class OtherViewController: UIViewController
{
    var username1 : String = ""
    var delegateModel:OtherViewDelegate!
    @IBOutlet weak var lblResponse: UILabel!
    override func viewDidLoad()
    {
        lblResponse.text = username1
        super.viewDidLoad()
    }
    @IBAction func btn(_ sender: Any)
    {
        self.delegateModel.Username(Username: username1)
        self.navigationController?.popViewController(animated: true)
    }
}
